# MathAI Control

Дайын статикалық сайт. Интернетсіз де браузерде жұмыс істейді.

## GitHub Pages-ке шығару
1. GitHub-та жаңа repository ашыңыз.
2. `index.html`, `style.css`, `script.js` файлдарын жүктеңіз.
3. Repository → Settings → Pages → Deploy from branch.
4. Branch: `main`, Folder: `/ (root)` → Save.
5. Бірнеше минуттан кейін сайт сілтемесі пайда болады.

Ескерту: Бұл нұсқа оқу жобасына арналған front-end прототип. Шешім тексеру JavaScript-тегі ережелер арқылы орындалады; толық AI/математикалық қозғалтқышқа серверлік бөлік қажет.
